
        let contador50_50 = 0;

        function ocultarDosBotones() {
            const iframe = document.getElementById("pregunta1");
            const iframeDocument = iframe.contentDocument || iframe.contentWindow.document;

            if (iframeDocument && iframeDocument.querySelector(".pregunta")) {
                const botonesPregunta = iframeDocument.querySelectorAll(".pregunta button");
                let contadorRespuestasIncorrectas = 0;

                botonesPregunta.forEach(boton => {
                    if (boton.getAttribute("data-es-correcto") === "false" && contadorRespuestasIncorrectas < 2) {
                        boton.style.display = "none";
                        contadorRespuestasIncorrectas++;
                    }
                });

                contador50_50++;
                document.getElementById("bt_50").disabled = contador50_50 === 3;
            }
        }
